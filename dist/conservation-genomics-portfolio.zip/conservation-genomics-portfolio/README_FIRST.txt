CONSERVATION GENOMICS PROJECT PORTFOLIO
========================================

START HERE
----------
1. Extract this entire ZIP archive. Do not open index.html from inside the ZIP.
2. Open index.html in any modern web browser.
3. No installation or internet connection is required for the website itself.

WHAT IS INCLUDED
----------------
- The complete offline project website and all 83 local targets it links to.
- All static CSS, JavaScript, figures, screenshots, reports, tables, validation records,
  project documentation, and the precomputed files used by the optional explorer app.
- 136 project files in total, plus this guide and MANIFEST.sha256.

For browsing this portfolio, internet access is needed only for external citation links. A fresh
reanalysis also needs network access to obtain the cited public datasets and tool sources.

OPTIONAL LOCAL SERVER
---------------------
Directly opening index.html works. For a hosting-style preview, run this command inside the
extracted conservation-genomics-portfolio folder:

    python -m http.server 8000

Then open http://localhost:8000/.

OPTIONAL EXPLORER APP
---------------------
The website is static and does not require Python packages. To run the separate Streamlit
explorer, install requirements.txt in an isolated environment and then run:

    python -m streamlit run app/streamlit_app.py

PACKAGE SCOPE
-------------
This is the sendable offline portfolio and its linked deliverables. Large public raw genomic
datasets and regenerable analysis intermediates are intentionally excluded because they are not
website dependencies. The included workflow and configuration files document reproducibility;
a complete reanalysis additionally requires the public datasets cited in the website and the
setup described in SETUP.md.

INTEGRITY
---------
MANIFEST.sha256 records the SHA-256 digest of every other file in this folder.
