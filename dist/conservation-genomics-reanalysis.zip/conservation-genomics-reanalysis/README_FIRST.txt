CONSERVATION GENOMICS PROJECT PORTFOLIO
========================================

START HERE
----------
1. Extract this entire ZIP archive. Do not open index.html from inside the ZIP.
2. Open index.html in any modern web browser.
3. No installation or internet connection is required for the website itself.
4. To personalize selected narrative text, double-click EDIT_WEBSITE.command (or run
   python3 scripts/python/edit_website.py), then follow EDIT_WEBSITE.md. Keep the
   launcher window open while editing; Python is needed to save edits, not to view
   the website.

WHAT IS INCLUDED
----------------
- The complete offline project website and all 144 local targets it links to.
- A private localhost editor for selected narrative text, with undo, reset, import,
  and export controls; scientific results and decision gates remain locked.
- All static CSS, JavaScript, figures, screenshots, reports, tables, validation records,
  project documentation, and the precomputed files used by the optional explorer app.
- 224 project files in total, plus this guide and MANIFEST.sha256.

For browsing this portfolio, internet access is needed only for external citation links. A fresh
reanalysis also needs network access to obtain the cited public datasets and tool sources.

OPTIONAL LOCAL SERVER
---------------------
Directly opening index.html works. For a hosting-style preview, run this command inside the
extracted conservation-genomics-reanalysis folder:

    python -m http.server 8000

Then open http://localhost:8000/.

OPTIONAL EXPLORER APP
---------------------
The website is static and does not require Python packages. To run the separate Streamlit
explorer, install requirements.txt in an isolated environment and then run:

    python -m streamlit run app/streamlit_app.py

PACKAGE SCOPE
-------------
This is the sendable offline portfolio and its linked deliverables. Large public raw genomic
datasets and regenerable analysis intermediates are intentionally excluded because they are not
website dependencies. The included workflow and configuration files document reproducibility;
a complete reanalysis additionally requires the public datasets cited in the website and the
setup described in SETUP.md.

INTEGRITY
---------
MANIFEST.sha256 records the SHA-256 digest of every other file in this folder.
